package teste.GameMania;

import java.io.InterruptedIOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TesteLogin {
	
	private WebDriver driver;
	
	@Before
	public void ConfigurarTeste() {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("http://localhost:4200/");
		
		//*[@id="navbarSupportedContent"]/div[2]/a - Xpath do link		
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/a")).click();
	}
	
	@Test
	public void TestarLogin() {
		
		WebElement campoEmail = driver.findElement(By.id("email"));
		WebElement campoSenha = driver.findElement(By.id("senha"));
		WebElement botao = driver.findElement(By.id("botao-enviar"));
		
		String [] listaEmails = {"josh@email.com", "jamesbond@email.com", "jamesbond@email.com"};
		String [] listaSenhas = {"85236974", "00000008", "00000007"};
		
		try {
			
			for(int contador = 0; contador < 3; contador++ ) {
				campoEmail.sendKeys(listaEmails[contador]);
				campoSenha.sendKeys(listaSenhas[contador]);
				botao.click();
				
				Thread.sleep(4000);
				
				campoEmail.clear();
				campoSenha.clear();
			}
			
			/*
			
			//1. Caso de teste: Email incorreto, que não está cadastrado
			//driver.findElement(By.id("email")).sendKeys("josh@email.com");
			//driver.findElement(By.id("senha")).sendKeys("85236974");
			//driver.findElement(By.id("botao-enviar")).click();
			
			//campoEmail.sendKeys("josh@email.com");
			//campoSenha.sendKeys("85236974");
			//botao.click();
									
			//Thread.sleep(4000);
			
			//Limpar os campos Login e Senha
			//driver.findElement(By.id("email")).clear();
			//driver.findElement(By.id("senha")).clear();
			
			//campoEmail.clear();
			//campoSenha.clear();
			
			//2. Caso de teste: Senha incorreta, para um email cadastrado
			//driver.findElement(By.id("email")).sendKeys("jamesbond@email.com");
			//driver.findElement(By.id("senha")).sendKeys("00000007");
			//driver.findElement(By.id("botao-enviar")).click();
			
			//campoEmail.sendKeys("jamesbond@email.com");
			//campoSenha.sendKeys("00000008");
			//botao.click();
			
			//Thread.sleep(4000);
			
			//Limpar os campos Login e Senha
			//driver.findElement(By.id("email")).clear();
			//driver.findElement(By.id("senha")).clear();
			
			//campoEmail.clear();
			//campoSenha.clear();
			
			//3. Usuário e senha correto
			//driver.findElement(By.id("email")).sendKeys("jamesbond@email.com");
			//driver.findElement(By.id("senha")).sendKeys("00000007");
			//driver.findElement(By.id("botao-enviar")).click();
			
			//campoEmail.sendKeys("jamesbond@email.com");
			//campoSenha.sendKeys("00000007");
			//botao.click();
			
			//Thread.sleep(4000);
			
			//Limpar os campos Login e Senha
			//driver.findElement(By.id("email")).clear();
			//driver.findElement(By.id("senha")).clear();
			
			//campoEmail.clear();
			//campoSenha.clear();
			
			*/
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}
	
	@After
	public void EncerrarTeste() {
		//driver.quit();
		
	}
}
